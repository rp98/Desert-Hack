Proof of concept of Project Kaya. 
 
